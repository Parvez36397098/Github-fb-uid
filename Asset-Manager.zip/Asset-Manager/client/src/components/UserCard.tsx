import { User } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Copy, Trash2, Eye, EyeOff, Facebook, CheckCircle2, XCircle } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { useDeleteUser } from "@/hooks/use-users";

interface UserCardProps {
  user: User;
  index: number;
}

export function UserCard({ user, index }: UserCardProps) {
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();
  const deleteUser = useDeleteUser();

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      description: `${label} copied to clipboard`,
      duration: 2000,
    });
  };

  const handleDelete = () => {
    deleteUser.mutate(user.uid, {
      onSuccess: () => {
        toast({
          description: "User deleted successfully",
          variant: "destructive",
        });
      },
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
    >
      <Card className="p-4 bg-muted/40 border-white/5 hover:border-white/10 hover:bg-muted/60 transition-all duration-300 group">
        <div className="flex items-start gap-4">
          <Avatar className="h-12 w-12 border-2 border-white/10 ring-2 ring-transparent group-hover:ring-primary/20 transition-all">
            <AvatarImage src={`https://graph.facebook.com/${user.uid}/picture?type=large`} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {user.name.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>

          <div className="flex-1 min-w-0 space-y-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-foreground truncate">{user.name}</h3>
                {user.isVerified ? (
                  <Badge variant="default" className="bg-green-500/10 text-green-500 hover:bg-green-500/20 border-green-500/20 h-5 px-1.5 gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Verified
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20 border-yellow-500/20 h-5 px-1.5 gap-1">
                    <XCircle className="w-3 h-3" />
                    Unverified
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                  onClick={() => window.open(`https://facebook.com/${user.uid}`, '_blank')}
                  title="View on Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive/70 hover:text-destructive hover:bg-destructive/10"
                  onClick={handleDelete}
                  disabled={deleteUser.isPending}
                  title="Delete User"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
              {/* UID Field */}
              <div className="flex items-center gap-2 bg-black/20 p-1.5 rounded-md border border-white/5">
                <span className="text-xs text-muted-foreground font-medium px-1">UID</span>
                <code className="text-xs font-mono text-foreground flex-1 truncate select-all">
                  {user.uid}
                </code>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-muted-foreground hover:text-primary"
                  onClick={() => copyToClipboard(user.uid, "UID")}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>

              {/* Password Field */}
              <div className="flex items-center gap-2 bg-black/20 p-1.5 rounded-md border border-white/5">
                <span className="text-xs text-muted-foreground font-medium px-1">PASS</span>
                <code className="text-xs font-mono text-foreground flex-1 truncate">
                  {showPassword ? user.password || "No Password" : "••••••••••••"}
                </code>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-muted-foreground hover:text-primary"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-muted-foreground hover:text-primary"
                  onClick={() => copyToClipboard(user.password || "", "Password")}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
