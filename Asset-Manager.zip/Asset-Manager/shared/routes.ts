
import { z } from 'zod';
import { insertUserSchema, users, fbResolveSchema, bulkImportSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/users' as const,
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/users' as const,
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/users/:uid' as const,
      responses: {
        200: z.object({ success: z.boolean(), message: z.string() }),
        404: errorSchemas.notFound,
      },
    },
    bulkImport: {
      method: 'POST' as const,
      path: '/api/bulk-import' as const,
      input: bulkImportSchema,
      responses: {
        200: z.object({ success: z.boolean(), imported: z.number(), total: z.number() }),
        400: errorSchemas.validation,
      },
    },
    deleteAll: {
      method: 'DELETE' as const,
      path: '/api/users' as const,
      responses: {
        200: z.object({ success: z.boolean(), message: z.string() }),
      },
    }
  },
  facebook: {
    resolve: {
      method: 'POST' as const,
      path: '/api/fetch-name' as const,
      input: fbResolveSchema,
      responses: {
        200: z.object({
          name: z.string(),
          firstName: z.string(),
          lastName: z.string(),
          picture: z.string().nullable(),
          source: z.string(),
          verified: z.boolean(),
          error: z.string().optional(),
        }),
      },
    },
    test: {
      method: 'GET' as const,
      path: '/api/test-facebook' as const,
      responses: {
        200: z.object({
          status: z.string(),
          message: z.string(),
          tokensConfigured: z.number(),
          data: z.any().optional(),
        }),
      },
    }
  },
  stats: {
    get: {
      method: 'GET' as const,
      path: '/api/stats' as const,
      responses: {
        200: z.object({
          total: z.number(),
          encrypted: z.number(),
          unencrypted: z.number(),
          verified: z.number(),
        }),
      },
    },
  },
  export: {
    download: {
      method: 'GET' as const,
      path: '/api/download/:format' as const,
      responses: {
        200: z.any(), // File download
      },
    },
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
