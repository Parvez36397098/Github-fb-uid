
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import axios from "axios";
import crypto from "crypto";

// Encryption settings
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'your-secret-key-change-this-min-32';
// Ensure key is 32 bytes
const KEY_BUFFER = Buffer.concat([Buffer.from(ENCRYPTION_KEY), Buffer.alloc(32)]).subarray(0, 32);

// Facebook Tokens from original server.js
const FB_TOKENS = [
  '350685531728|62f8ce9f74b12f84c123cc23437a4a32',
  '256002347743983|374e60f8b9bb6b8cbb30f78030438895',
];

// Helper: Get Token
function getRandomToken() {
  const envToken = process.env.FB_ACCESS_TOKEN;
  if (envToken && envToken !== 'optional') return envToken;
  return FB_TOKENS[Math.floor(Math.random() * FB_TOKENS.length)];
}

// Helper: Encryption
function encrypt(text: string): string {
  if (!text) return text;
  try {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', KEY_BUFFER, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return iv.toString('hex') + ':' + encrypted;
  } catch (e) {
    console.error("Encryption error:", e);
    return text;
  }
}

function decrypt(text: string): string {
  if (!text || !text.includes(':')) return text;
  try {
    const parts = text.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY_BUFFER, iv);
    let decrypted = decipher.update(parts[1], 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (e) {
    // Return original if decryption fails (might be unencrypted)
    return text;
  }
}

async function seedDatabase() {
  const users = await storage.getUsers();
  if (users.length === 0) {
    console.log("Seeding database...");
    const seedUsers = [
      { uid: '4', name: 'Mark Zuckerberg', password: 'password123', isEncrypted: true, isVerified: true },
      { uid: '123456789', name: 'Test User', password: 'testpassword', isEncrypted: true, isVerified: false },
    ];
    
    for (const u of seedUsers) {
      const encryptedPass = encrypt(u.password);
      await storage.createUser({
        ...u,
        password: encryptedPass
      });
    }
    console.log("Database seeded!");
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed DB
  seedDatabase();

  // --- Facebook API ---
  app.post(api.facebook.resolve.path, async (req, res) => {
    try {
      const { uid } = api.facebook.resolve.input.parse(req.body);
      
      const token = getRandomToken();
      // Retry logic could go here, but keeping it simple for now as per MVP
      try {
        const response = await axios.get(`https://graph.facebook.com/v18.0/${uid}`, {
          params: {
            fields: 'name,first_name,last_name,picture.type(small)',
            access_token: token
          },
          timeout: 5000
        });

        if (response.data.name) {
          return res.json({
            name: response.data.name,
            firstName: response.data.first_name || '',
            lastName: response.data.last_name || '',
            picture: response.data.picture?.data?.url || null,
            source: 'facebook',
            verified: true
          });
        }
      } catch (fbError: any) {
        console.error(`FB API Error for ${uid}:`, fbError.message);
      }

      // Fallback
      res.json({
        name: `User_${uid.substring(0, 6)}`,
        firstName: '',
        lastName: '',
        picture: null,
        source: 'default',
        verified: false,
        error: 'Could not resolve from Facebook'
      });
    } catch (err) {
      res.status(400).json({ message: "Invalid Request" });
    }
  });

  app.get(api.facebook.test.path, async (req, res) => {
    try {
      const token = getRandomToken();
      const response = await axios.get('https://graph.facebook.com/me', {
        params: { access_token: token },
        timeout: 5000
      });
      res.json({
        status: 'success',
        message: '✅ Facebook API Connected',
        tokensConfigured: FB_TOKENS.length,
        data: response.data
      });
    } catch (error: any) {
      res.json({
        status: 'error',
        message: `❌ ${error.message}`,
        tokensConfigured: FB_TOKENS.length
      });
    }
  });

  // --- Users API ---
  app.get(api.users.list.path, async (req, res) => {
    const users = await storage.getUsers();
    // Decrypt passwords for display
    const decryptedUsers = users.map(u => ({
      ...u,
      password: u.isEncrypted ? decrypt(u.password || '') : u.password
    }));
    res.json(decryptedUsers);
  });

  app.post(api.users.create.path, async (req, res) => {
    try {
      const input = api.users.create.input.parse(req.body);
      
      // Auto-encrypt if not already (assuming input is raw)
      // The schema has isEncrypted, but typically we want to enforce encryption here
      // But let's respect the isEncrypted flag if passed, or default to true for new passwords
      
      let password = input.password || '';
      let isEncrypted = input.isEncrypted || false;

      // Force encryption for new users if password exists
      if (password && !isEncrypted) {
        password = encrypt(password);
        isEncrypted = true;
      }

      const user = await storage.createUser({
        ...input,
        password,
        isEncrypted
      });
      
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  app.delete(api.users.delete.path, async (req, res) => {
    await storage.deleteUser(req.params.uid);
    res.json({ success: true, message: "User deleted" });
  });

  app.delete(api.users.deleteAll.path, async (req, res) => {
    await storage.deleteAllUsers();
    res.json({ success: true, message: "All users deleted" });
  });

  // --- Bulk Import ---
  app.post(api.users.bulkImport.path, async (req, res) => {
    try {
      const { data, encrypted } = api.users.bulkImport.input.parse(req.body);
      
      const usersToInsert = data.map(item => ({
        uid: item.uid,
        name: item.name || `User_${item.uid.substring(0, 6)}`,
        password: encrypted ? encrypt(item.password || '') : (item.password || ''),
        isEncrypted: !!encrypted,
        isVerified: item.verified || false
      }));

      await storage.bulkCreateUsers(usersToInsert);
      const total = (await storage.getStats()).total;
      
      res.json({ success: true, imported: usersToInsert.length, total });
    } catch (err) {
      res.status(400).json({ message: "Invalid Data" });
    }
  });

  // --- Stats ---
  app.get(api.stats.get.path, async (req, res) => {
    const stats = await storage.getStats();
    res.json(stats);
  });

  // --- Export ---
  app.get(api.export.download.path, async (req, res) => {
    const format = req.params.format;
    const users = await storage.getUsers();
    const decryptedUsers = users.map(u => ({
      ...u,
      password: u.isEncrypted ? decrypt(u.password || '') : u.password
    }));

    if (format === 'txt') {
      let content = 'UID|PASSWORD|NAME|VERIFIED\n';
      content += '─'.repeat(80) + '\n';
      decryptedUsers.forEach(u => {
        const verified = u.isVerified ? '✅' : '❌';
        content += `${u.uid}|${u.password}|${u.name}|${verified}\n`;
      });
      res.header('Content-Disposition', 'attachment; filename="UID_Data.txt"');
      res.header('Content-Type', 'text/plain');
      res.send(content);
    } else if (format === 'json') {
      res.header('Content-Disposition', 'attachment; filename="UID_Data.json"');
      res.header('Content-Type', 'application/json');
      res.send(JSON.stringify(decryptedUsers, null, 2));
    } else if (format === 'csv') {
      let content = 'UID,PASSWORD,NAME,ENCRYPTED,VERIFIED,SAVED_AT\n';
      decryptedUsers.forEach(u => {
        const pass = (u.password || '').replace(/,/g, ';');
        const name = (u.name || '').replace(/,/g, ';');
        content += `${u.uid},"${pass}","${name}",${u.isEncrypted},${u.isVerified},"${u.createdAt}"\n`;
      });
      res.header('Content-Disposition', 'attachment; filename="UID_Data.csv"');
      res.header('Content-Type', 'text/csv');
      res.send(content);
    } else {
      res.status(400).send("Invalid format");
    }
  });

  return httpServer;
}
