import { useState } from "react";
import { useUsers, useCreateUser, useResolveFacebookUser, useTestFacebook, useDeleteAllUsers } from "@/hooks/use-users";
import { UserCard } from "@/components/UserCard";
import { StatsBar } from "@/components/StatsBar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Play, RotateCcw, AlertCircle, Loader2, Info, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export default function Dashboard() {
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const { toast } = useToast();

  const { data: users, isLoading: usersLoading } = useUsers();
  const { data: fbStatus } = useTestFacebook();
  const createUser = useCreateUser();
  const resolveUser = useResolveFacebookUser();
  const deleteAllUsers = useDeleteAllUsers();

  const handleClearAll = async () => {
    if (window.confirm("Are you sure you want to delete all saved accounts? This cannot be undone.")) {
      try {
        await deleteAllUsers.mutateAsync();
        toast({ title: "Success", description: "All accounts have been cleared" });
      } catch (error) {
        toast({ title: "Error", description: "Failed to clear accounts", variant: "destructive" });
      }
    }
  };

  const handleProcess = async () => {
    if (!input.trim()) {
      toast({ description: "Please enter some data first", variant: "destructive" });
      return;
    }

    const lines = input.split("\n").filter(line => line.trim().length > 0);
    if (lines.length === 0) return;

    setIsProcessing(true);
    setProgress({ current: 0, total: lines.length });
    
    let processedCount = 0;
    let errorCount = 0;

    for (const line of lines) {
      // Basic format check
      if (!line.includes("|")) {
        console.warn(`Skipping invalid line: ${line}`);
        errorCount++;
        setProgress(prev => ({ ...prev, current: prev.current + 1 }));
        continue;
      }

      const [uid, password] = line.split("|").map(s => s.trim());
      
      try {
        // 1. Resolve Name
        const fbData = await resolveUser.mutateAsync(uid);
        
        // 2. Create User
        await createUser.mutateAsync({
          uid,
          password,
          name: fbData.name || "Unknown User",
          isVerified: fbData.verified,
          isEncrypted: false, // Backend handles this logic usually, or send false
        });
        
        processedCount++;
      } catch (error) {
        console.error(`Failed to process ${uid}:`, error);
        errorCount++;
      }
      
      setProgress(prev => ({ ...prev, current: prev.current + 1 }));
    }

    setIsProcessing(false);
    toast({
      title: "Processing Complete",
      description: `Successfully processed ${processedCount} users. ${errorCount} failed.`,
      variant: errorCount > 0 ? "default" : "default", // Using default for success with checkmark effectively
    });
    
    // Optional: Clear input on success
    if (processedCount > 0) {
      setInput("");
    }
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-white/60 bg-clip-text text-transparent">
              FB UID Manager Pro
            </h1>
            <p className="text-muted-foreground mt-1">
              Securely manage and verify Facebook accounts in bulk.
            </p>
          </div>
          
          {fbStatus && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20">
              <div className={`w-2 h-2 rounded-full ${fbStatus.status === 'ok' ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-xs font-medium text-blue-200">
                System: {fbStatus.tokensConfigured > 0 ? 'Online' : 'Restricted Mode'}
              </span>
            </div>
          )}
        </header>

        {/* Stats */}
        <StatsBar />

        {/* Main Action Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Input Section */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="bg-card/50 border-white/5 shadow-xl backdrop-blur-sm h-full flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Info className="w-5 h-5 text-primary" />
                  Bulk Input
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col gap-4">
                <Alert className="bg-blue-500/5 border-blue-500/10">
                  <AlertCircle className="h-4 w-4 text-blue-500" />
                  <AlertTitle className="text-blue-500">Format Required</AlertTitle>
                  <AlertDescription className="text-blue-500/80 text-xs">
                    Paste one account per line in strict format: <br/>
                    <code className="bg-black/30 px-1 py-0.5 rounded ml-1">UID|PASSWORD</code>
                  </AlertDescription>
                </Alert>
                
                <Textarea
                  placeholder="100000000000001|password123&#10;100000000000002|securepass"
                  className="flex-1 min-h-[300px] font-mono text-sm bg-black/20 border-white/10 focus:border-primary/50 resize-none p-4"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={isProcessing}
                />
                
                <div className="flex gap-3 pt-2">
                  <Button
                    variant="destructive"
                    className="flex-1 opacity-90 hover:opacity-100"
                    onClick={() => setInput("")}
                    disabled={!input || isProcessing}
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Clear
                  </Button>
                  <Button
                    className="flex-[2] bg-white text-black hover:bg-white/90"
                    onClick={handleProcess}
                    disabled={!input || isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {progress.total > 0 
                          ? `Processing ${progress.current}/${progress.total}` 
                          : "Processing..."}
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2 fill-current" />
                        Process List
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div className="lg:col-span-2">
            <Card className="bg-card/50 border-white/5 shadow-xl backdrop-blur-sm h-full min-h-[500px] flex flex-col">
              <CardHeader className="border-b border-white/5 pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <CardTitle>Saved Accounts</CardTitle>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-destructive hover:text-destructive hover:bg-destructive/10 h-8"
                      onClick={handleClearAll}
                      disabled={!users || users.length === 0 || deleteAllUsers.isPending}
                    >
                      {deleteAllUsers.isPending ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" />
                      ) : (
                        <Trash2 className="w-3.5 h-3.5 mr-1.5" />
                      )}
                      Delete All
                    </Button>
                  </div>
                  <span className="text-sm text-muted-foreground bg-white/5 px-2 py-1 rounded-md">
                    {users?.length || 0} Records
                  </span>
                </div>
              </CardHeader>
              <CardContent className="p-0 flex-1 overflow-hidden flex flex-col">
                {usersLoading ? (
                  <div className="flex-1 flex items-center justify-center p-8">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : users && users.length > 0 ? (
                  <div className="overflow-y-auto h-[600px] p-4 space-y-3 custom-scrollbar">
                    <AnimatePresence>
                      {users.map((user, idx) => (
                        <UserCard key={user.uid} user={user} index={idx} />
                      ))}
                    </AnimatePresence>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground p-8">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
                      <Info className="w-8 h-8 opacity-50" />
                    </div>
                    <p>No accounts processed yet.</p>
                    <p className="text-sm opacity-60">Add some UIDs to get started.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
