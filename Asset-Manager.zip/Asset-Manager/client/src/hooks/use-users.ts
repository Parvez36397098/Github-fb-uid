import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { InsertUser, User, UserStats } from "@shared/schema";

// Helper to handle API requests that might throw
async function fetcher<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, { ...options, credentials: "include" });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: "An error occurred" }));
    throw new Error(error.message || res.statusText);
  }
  return res.json();
}

// GET /api/users
export function useUsers() {
  return useQuery({
    queryKey: [api.users.list.path],
    queryFn: () => fetcher<User[]>(api.users.list.path),
  });
}

// POST /api/users
export function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertUser) =>
      fetcher<User>(api.users.create.path, {
        method: api.users.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.stats.get.path] });
    },
  });
}

// DELETE /api/users/:uid
export function useDeleteUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (uid: string) => {
      const url = buildUrl(api.users.delete.path, { uid });
      return fetcher(url, { method: api.users.delete.method });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.stats.get.path] });
    },
  });
}

// DELETE /api/users
export function useDeleteAllUsers() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => fetcher(api.users.deleteAll.path, { method: api.users.deleteAll.method }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.stats.get.path] });
    },
  });
}

// POST /api/fetch-name (FB Resolve)
export function useResolveFacebookUser() {
  return useMutation({
    mutationFn: (uid: string) =>
      fetcher<any>(api.facebook.resolve.path, {
        method: api.facebook.resolve.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uid }),
      }),
  });
}

// GET /api/stats
export function useUserStats() {
  return useQuery({
    queryKey: [api.stats.get.path],
    queryFn: () => fetcher<UserStats>(api.stats.get.path),
    refetchInterval: 5000, // Poll every 5s to keep stats fresh
  });
}

// GET /api/test-facebook
export function useTestFacebook() {
  return useQuery({
    queryKey: [api.facebook.test.path],
    queryFn: () => fetcher<{ status: string; message: string; tokensConfigured: number }>(api.facebook.test.path),
    retry: false,
  });
}
