import { useUserStats } from "@/hooks/use-users";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Users, Lock, Unlock, ShieldCheck } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";

export function StatsBar() {
  const { data: stats, isLoading } = useUserStats();

  const handleDownload = (format: string) => {
    window.location.href = `/api/download/${format}`;
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-24 rounded-xl bg-muted/40" />
        ))}
      </div>
    );
  }

  if (!stats) return null;

  return (
    <div className="space-y-4 mb-8">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          label="Total Users"
          value={stats.total}
          icon={Users}
          color="text-blue-500"
          bg="bg-blue-500/10"
        />
        <StatCard
          label="Verified"
          value={stats.verified}
          icon={ShieldCheck}
          color="text-green-500"
          bg="bg-green-500/10"
        />
        <StatCard
          label="Encrypted"
          value={stats.encrypted}
          icon={Lock}
          color="text-purple-500"
          bg="bg-purple-500/10"
        />
        <StatCard
          label="Unencrypted"
          value={stats.unencrypted}
          icon={Unlock}
          color="text-orange-500"
          bg="bg-orange-500/10"
        />
      </div>

      <div className="flex justify-end">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="gap-2 border-white/10 hover:bg-white/5">
              <Download className="w-4 h-4" />
              Export Data
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-popover border-white/10">
            <DropdownMenuItem onClick={() => handleDownload('txt')} className="cursor-pointer">
              Download as .TXT
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleDownload('json')} className="cursor-pointer">
              Download as .JSON
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleDownload('csv')} className="cursor-pointer">
              Download as .CSV
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, color, bg }: any) {
  return (
    <Card className="p-4 bg-muted/30 border-white/5 flex items-center gap-4 hover:bg-muted/50 transition-colors">
      <div className={`p-3 rounded-xl ${bg} ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <p className="text-sm text-muted-foreground font-medium">{label}</p>
        <p className="text-2xl font-bold tracking-tight">{value}</p>
      </div>
    </Card>
  );
}
