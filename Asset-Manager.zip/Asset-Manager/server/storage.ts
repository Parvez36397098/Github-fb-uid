
import { db } from "./db";
import { users, type User, type InsertUser, type UserStats } from "@shared/schema";
import { eq, count, sql } from "drizzle-orm";

export interface IStorage {
  // User Operations
  getUsers(): Promise<User[]>;
  getUser(uid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(uid: string, user: Partial<InsertUser>): Promise<User>;
  deleteUser(uid: string): Promise<void>;
  
  // Bulk Operations
  bulkCreateUsers(usersList: InsertUser[]): Promise<void>;
  deleteAllUsers(): Promise<void>;
  
  // Stats
  getStats(): Promise<UserStats>;
}

export class DatabaseStorage implements IStorage {
  async getUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(sql`${users.createdAt} DESC`);
  }

  async getUser(uid: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.uid, uid));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .onConflictDoUpdate({
        target: users.uid,
        set: insertUser,
      })
      .returning();
    return user;
  }

  async updateUser(uid: string, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.uid, uid))
      .returning();
    return user;
  }

  async deleteUser(uid: string): Promise<void> {
    await db.delete(users).where(eq(users.uid, uid));
  }

  async deleteAllUsers(): Promise<void> {
    await db.delete(users);
  }

  async bulkCreateUsers(usersList: InsertUser[]): Promise<void> {
    if (usersList.length === 0) return;
    
    // Drizzle's ON CONFLICT DO UPDATE is great here
    await db
      .insert(users)
      .values(usersList)
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          name: sql`excluded.name`,
          password: sql`excluded.password`,
          isEncrypted: sql`excluded.is_encrypted`,
          isVerified: sql`excluded.is_verified`,
        },
      });
  }

  async getStats(): Promise<UserStats> {
    const [totalRes] = await db.select({ count: count() }).from(users);
    const [encryptedRes] = await db.select({ count: count() }).from(users).where(eq(users.isEncrypted, true));
    const [verifiedRes] = await db.select({ count: count() }).from(users).where(eq(users.isVerified, true));
    
    const total = Number(totalRes?.count || 0);
    const encrypted = Number(encryptedRes?.count || 0);
    const verified = Number(verifiedRes?.count || 0);
    
    return {
      total,
      encrypted,
      unencrypted: total - encrypted,
      verified,
    };
  }
}

export const storage = new DatabaseStorage();
