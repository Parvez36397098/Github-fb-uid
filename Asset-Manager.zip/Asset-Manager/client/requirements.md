## Packages
framer-motion | Smooth animations for list items and transitions
lucide-react | Beautiful icons for the UI (already in base, but ensuring)
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
The application requires a dark theme by default.
The input format for the bulk processor is strictly `UID|PASSWORD`.
We need to handle potential rate limits or errors from the FB fetch endpoint gracefully in the UI.
