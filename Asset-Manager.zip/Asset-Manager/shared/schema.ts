
import { pgTable, text, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  uid: text("uid").primaryKey(), // Facebook UID is unique
  password: text("password").default(""),
  name: text("name").notNull(),
  isEncrypted: boolean("is_encrypted").default(false),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users);

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// API Types
export type UserStats = {
  total: number;
  encrypted: number;
  unencrypted: number;
  verified: number;
};

export type FacebookProfile = {
  name: string;
  firstName: string;
  lastName: string;
  picture: string | null;
  source: 'facebook' | 'default';
  verified: boolean;
  error?: string;
};

export const fbResolveSchema = z.object({
  uid: z.string().min(1),
});

export const bulkImportSchema = z.object({
  data: z.array(z.object({
    uid: z.string(),
    password: z.string().optional(),
    name: z.string().optional(),
    verified: z.boolean().optional(),
  })),
  encrypted: z.boolean().optional(),
});
