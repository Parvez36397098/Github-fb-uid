# replit.md

## Overview

FB UID Manager Pro — a full-stack web application for managing Facebook UIDs (user IDs) with associated passwords. The app allows users to bulk-import `UID|PASSWORD` pairs, resolve Facebook profile names via the Graph API, encrypt/decrypt stored passwords using AES-256-CBC, and download data in various formats. It features a dark-themed dashboard with stats, animated user cards, and CRUD operations on stored accounts.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework:** React 18 with TypeScript, bundled by Vite
- **Routing:** Wouter (lightweight client-side router)
- **State/Data Fetching:** TanStack React Query for server state management
- **UI Components:** shadcn/ui (new-york style) built on Radix UI primitives
- **Styling:** Tailwind CSS with CSS variables for theming; dark mode by default
- **Animations:** Framer Motion for list item transitions
- **Icons:** Lucide React
- **Structure:** Single-page app with a Dashboard as the main page. Components live in `client/src/components/`, hooks in `client/src/hooks/`, pages in `client/src/pages/`
- **Path aliases:** `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend
- **Runtime:** Node.js with Express, written in TypeScript (executed via tsx)
- **API Pattern:** RESTful JSON API under `/api/` prefix. Route definitions are shared between client and server via `shared/routes.ts`
- **Key Endpoints:**
  - `GET/POST /api/users` — list and create users
  - `DELETE /api/users/:uid` — delete a user
  - `POST /api/bulk-import` — bulk import UID/password pairs
  - `DELETE /api/users` — delete all users
  - `GET /api/stats` — get aggregate stats
  - `POST /api/resolve-fb` — resolve a Facebook UID to a profile name via Graph API
  - `GET /api/download/:format` — export data
- **Encryption:** AES-256-CBC encryption for passwords, using `ENCRYPTION_KEY` env var
- **Facebook Integration:** Uses Facebook Graph API app tokens to resolve UID → name. Tokens are hardcoded as fallback with env var override (`FB_ACCESS_TOKEN`)

### Shared Code
- `shared/schema.ts` — Drizzle ORM table definitions and Zod schemas (single `users` table)
- `shared/routes.ts` — API route contracts with Zod validation schemas, shared between frontend and backend

### Database
- **ORM:** Drizzle ORM with PostgreSQL dialect
- **Connection:** `node-postgres` (pg) Pool, configured via `DATABASE_URL` environment variable
- **Schema:** Single `users` table with columns: `uid` (PK, text), `password` (text), `name` (text), `is_encrypted` (boolean), `is_verified` (boolean), `created_at` (timestamp)
- **Migrations:** Managed via `drizzle-kit push` (push-based, no migration files needed for dev)
- **Storage Layer:** `server/storage.ts` implements `IStorage` interface with `DatabaseStorage` class wrapping Drizzle queries

### Build System
- **Dev:** `tsx server/index.ts` runs the server which sets up Vite dev middleware for HMR
- **Production Build:** Custom `script/build.ts` that runs Vite build for client and esbuild for server, outputting to `dist/`
- **Server serves client:** In production, Express serves the built static files from `dist/public/`

## External Dependencies

### Database
- **PostgreSQL** — Required. Connection string via `DATABASE_URL` environment variable. Must be provisioned before the app can start.

### Facebook Graph API
- Used to resolve Facebook UIDs to profile names and pictures
- App tokens are hardcoded as defaults; can be overridden with `FB_ACCESS_TOKEN` env var
- Profile pictures loaded client-side from `graph.facebook.com/{uid}/picture`

### Environment Variables
- `DATABASE_URL` (required) — PostgreSQL connection string
- `ENCRYPTION_KEY` (optional) — Key for AES-256-CBC password encryption (defaults to a placeholder; should be changed for security)
- `FB_ACCESS_TOKEN` (optional) — Facebook Graph API access token override
- `PORT` (optional) — Server port, defaults to 5000

### Key npm Packages
- `drizzle-orm` + `drizzle-kit` — ORM and schema management
- `express` — HTTP server
- `axios` — HTTP client for Facebook API calls
- `crypto` (Node built-in) — AES-256-CBC encryption
- `@tanstack/react-query` — Client-side data fetching
- `framer-motion` — Animations
- `zod` + `drizzle-zod` — Schema validation
- `wouter` — Client-side routing
- Full shadcn/ui component library (Radix UI primitives)